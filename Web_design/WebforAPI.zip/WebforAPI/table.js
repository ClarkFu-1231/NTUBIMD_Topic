// use express method
var express = require('express');
var app = express();

// create ejs
var engine = require('ejs-locals');
app.engine('ejs',engine);
app.set('views','./views');
app.set('view engine','ejs');

var mysql = require('mysql');

// connect MySQL
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'password',
  database: 'test'
});


// create object
var data = {};
// select sfp table and print all colums
connection.query('select * from sfp where id =1001', function(err, rows, fields) {
    if (err) throw err;
    // set data to object
    console.log('The solution is: ', rows);
    data.user = rows[0];
});


app.get('/', function(req, res) {
    // add data property to about page
    res.render('table', { data: data.user });
});

// check running enviroment
var port = process.env.PORT || 80;

// create
app.listen(port);

// only print hint link for local enviroment
if (port === 80) {
    console.log('RUN http://localhost:80/');
}

