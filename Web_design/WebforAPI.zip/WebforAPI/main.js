var mysql = require('mysql');

var path = require('path');

// Some constances
const express = require('express')
const app = express()

// create ejs
var engine = require('ejs-locals');
app.engine('ejs',engine);
app.set('views','./views');
app.set('view engine','ejs');

const hostName = 'localhost';
const port = 5000;
// Setup static folder
app.use(express.static(__dirname + "/static/"));

// Creating mysql connection pool
var con  = mysql.createPool({
	host: "localhost",
	user: "root",
	password: "password",
	database:"test"
});


// rendering html file 1101.
app.get('/', (req, res) => {
	
	// JSON Response of table query
	app.get('/data.json', (req, res) => {
		res.writeHead(200, {'Content-Type': 'text/html;charset=utf-8'});
		sql = mysql.format('SELECT * FROM test where id = 1101');
		con.query(sql, function (err, result) {
			res.write(JSON.stringify(result));
			res.end();
		});
	})
	console.log(req.url);
	res.sendFile(path.join(__dirname + '/index.html'));
})


app.listen(port, () => console.log(`Example app listening on port  http://${hostName}:${port}`))