#建立回歸分析的神經網路
#使用keras 建構神經網路
#適用K-fold 交叉驗證
import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense

#指定亂數種子
np.random.seed(7)

#載入資料集
df = pd.read_csv("./boston_data.csv")
dataset = df.values
np.random.shuffle(dataset)

#使用Pandas載入CSV檔案，使用values屬性轉換成NumPy陣列
#分隔成前13個欄位的特徵資料和第14個欄位的標籤資料
X = dataset[:, 0:13]
Y = dataset[:, 13]
X -= X.mean(axis=0)
X /= X.std(axis=0)
X_train, Y_train = X[:323], Y[:323]  #訓練資料(80%)
X_test, Y_test = X[323:], Y[323:]  #測試資料(20%)

#建立build_model()建立模型
#三層神經層
def build_model():
    model = Sequential()
    model.add(Dense(32, input_shape=(X_train.shape[1], ),activation="relu"))
    model.add(Dense(1))
    model.compile(loss="mse", optimizer="adam", metrics=["mae"])#compile()使用的損失函數MSE,評估標準metrics是MAE
    #反映預測值與標籤值誤差實際情況
    return model

#K-fold交叉驗證
k=4 
nb_val_samples = len(X_train) // k#每一折的樣本數
nb_epochs = 80 #訓練週期
mse_scores = [] #mse_scores紀錄mse每一次的迴圈評估模型
mae_scores = [] #mae_scores紀錄mae每一次的迴圈評估模型

#for迴圈共執行K=4次
#使用切割運算子取出第K個驗證資料集X_val和Y_val
for i in range(k):
    print("Processing Fold #" +str(i))
    X_val = X_train[i*nb_val_samples: (i+1)*nb_val_samples]
    Y_val = Y_train[i*nb_val_samples: (i+1)*nb_val_samples]
    #使用concatenate()結合剩下的折建立X_train_p和Y_train_p
    X_train_p = np.concatenate(
            [X_train[:i*nb_val_samples],
             X_train[(i+1)*nb_val_samples:]], axis=0)
    Y_train_p = np.concatenate(
            [Y_train[:i*nb_val_samples],
             Y_train[(i+1)*nb_val_samples:]], axis=0)
    #呼叫build_model()建立神經網路模型
    model = build_model()
    model.fit(X_train_p, Y_train_p, epochs=nb_epochs, batch_size=16, verbose=0) #fit()訓練模型
    mse, mae = model.evaluate(X_val, Y_val) #evaluate()評估模型
    mse_scores.append(mse) #mse評估結果儲存
    mae_scores.append(mae) #mae評估結果儲存
    
#顯示完成4次迴圈後的K-fold交叉驗證的MSE和MAE的平均值
print("MSE_val: ", np.mean(mse_scores))
print("MAE_val: ", np.mean(mae_scores))
mse, mae= model.evaluate(X_test, Y_test)
print("MSE_test: ",mse)
print("MAE_test: ",mae)