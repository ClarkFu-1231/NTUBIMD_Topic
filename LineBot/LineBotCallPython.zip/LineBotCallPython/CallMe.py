# -*- coding: utf-8 -*-
"""
Created on Thu Apr  8 19:05:41 2021

@author: HAO
"""

import sys 
import json

result = {
    "Text":sys.argv[1]*2
  }
json = json.dumps(result)
print(str(json))
sys.stdout.flush()