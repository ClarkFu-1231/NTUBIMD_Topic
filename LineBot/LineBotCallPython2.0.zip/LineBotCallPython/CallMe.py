# -*- coding: utf-8 -*-
"""
Created on Thu Apr  8 19:05:41 2021

@author: HAO
"""
#sys用於取得輸入資料
#json用於轉換資料格式
import sys 
import json

result = {
	#sys.argv[0]為檔案名稱
	#sys.argv[1]為輸入資料
	#sys.argv[n]看有幾筆輸入資料就到多少
    "Text":sys.argv[1]*2
  }
#將result(dict)轉為json
json = json.dumps(result)
#以字串型式回傳資料
print(str(json))
sys.stdout.flush()